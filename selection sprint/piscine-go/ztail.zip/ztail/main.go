package main

import (
	"fmt"
	"os"
)

func main() {
	args := os.Args[1:]
	nb := 0
	r := 0
	if len(args) > 0 {
		if os.Args[1] == "-c" {
			nb = Atoi(os.Args[2])
			for f, s := range os.Args[3:] {
				data, err := os.ReadFile(s)
				if err != nil {
					fmt.Printf(err.Error() + "\n")
					r++
				} else {
					if len(string(data)) >= nb {
						if f != 0 {
							fmt.Printf("\n")
						}
						fmt.Println("==>", s, "<==")
						last := data[len(string(data))-nb:]
						fmt.Print(string(last))
					} else {
						if f != 0 {
							fmt.Printf("\n")
						}
						fmt.Println("==>", s, "<==")
						fmt.Print(string(data))
					}
				}
			}
			if r > 0 {
				os.Exit(1)
			}
		} else {
			for f, s := range os.Args[1:] {
				data, err := os.ReadFile(s)
				if err != nil {
					fmt.Printf(err.Error() + "\n")
					r++
				} else {
					if f != 0 {
						fmt.Printf("\n")
					}
					fmt.Println("==>", s, "<==")
					fmt.Print(string(data))
				}
			}
			if r > 0 {
				os.Exit(1)
			}
		}
	}
}

func Atoi(s string) int {
	o_number := 0
	c := 0
	checker := true
	a_s := []rune(s)
	pl := 1

	if s != "" {
		if byte(a_s[0]) == 45 {
			pl = -1
			a_s[0] = '0'
		} else if byte(a_s[0]) == 43 {
			a_s[0] = '0'
		}
	}
	for _, word := range a_s {
		if byte(word) >= 48 && byte(word) <= 57 {
			for i := '0'; i < word; i++ {
				c++
			}
			o_number = o_number*10 + c
			c = 0
		} else {
			checker = false
		}
	}

	if checker {
		return o_number * pl
	} else {
		return 0
	}
}
